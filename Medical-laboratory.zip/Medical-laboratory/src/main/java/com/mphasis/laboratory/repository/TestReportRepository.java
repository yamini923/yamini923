package com.mphasis.laboratory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.laboratory.entity.TestReport;

public interface TestReportRepository extends JpaRepository<TestReport,String>{

}

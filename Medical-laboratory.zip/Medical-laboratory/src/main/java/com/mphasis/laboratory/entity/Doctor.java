package com.mphasis.laboratory.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="DOCTOR")
public class Doctor {
	@Id
	private String doctorId;
	private String doctorFirstName;
	private String doctorLastName;
	private String doctorPhoneNumber;
	private String doctorEmail;
	private String qualification;
	
	 @OneToMany(fetch = FetchType.LAZY,
	            cascade =  CascadeType.ALL,
	            mappedBy = "doctor")
	 private List<Appointment> appointmentList;
	
	
/*    --------To implement profile picture of doctor*/	
	@JsonIgnore
	@Column(columnDefinition = "LONGBLOB")
	@Lob
	
	private byte[] profilePicture;
	public byte[] getProfilePicture() {
		return profilePicture;
	}
	public void setProfilePicture(byte[] profilePicture) {
		this.profilePicture = profilePicture;
	}
	public Doctor(String doctorId, String doctorFirstName,String doctorLastName, String doctorPhoneNumber, String doctorEmail, String qualification,
			byte[] profilePicture) {
		super();
		this.doctorId = doctorId;
		this.doctorFirstName = doctorFirstName;
		this.doctorLastName=doctorLastName;
		this.doctorPhoneNumber = doctorPhoneNumber;
		this.doctorEmail = doctorEmail;
		this.qualification = qualification;
		this.profilePicture = profilePicture;
	}
//	-------------------------------------------------------------------------------------------------
	
	
	
	public Doctor() {}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	
	public String getDoctorEmail() {
		return doctorEmail;
	}
	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getDoctorFirstName() {
		return doctorFirstName;
	}
	public void setDoctorFirstName(String doctorFirstName) {
		this.doctorFirstName = doctorFirstName;
	}
	public String getDoctorLastName() {
		return doctorLastName;
	}
	public void setDoctorLastName(String doctorLastName) {
		this.doctorLastName = doctorLastName;
	}
	public String getDoctorPhoneNumber() {
		return doctorPhoneNumber;
	}
	public void setDoctorPhoneNumber(String doctorPhoneNumber) {
		this.doctorPhoneNumber = doctorPhoneNumber;
	}

	public String getprofilePicture()
	{
		String x=Base64.encodeBase64String(profilePicture);
		return x;
	}
	
	public Doctor(String doctorId, String doctorFirstName, String doctorLastName, String doctorPhoneNumber,
			String doctorEmail, String qualification) {
		super();
		this.doctorId = doctorId;
		this.doctorFirstName = doctorFirstName;
		this.doctorLastName = doctorLastName;
		this.doctorPhoneNumber = doctorPhoneNumber;
		this.doctorEmail = doctorEmail;
		this.qualification = qualification;
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorFirstName=" + doctorFirstName + ", doctorLastName="
				+ doctorLastName + ", doctorPhoneNumber=" + doctorPhoneNumber + ", doctorEmail=" + doctorEmail
				+ ", qualification=" + qualification + "]";
	}
	
	
	

}

package com.mphasis.laboratory.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="APPOINTMENT")
public class Appointment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String appointmentId;
	private Date	appointmentDate;
	private String	timeSlot;
	
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "patientId", nullable = false)
	    private Patient patient;
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "doctorId", nullable = false)
	    private Doctor doctor;
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "testId", nullable = false)
	    private MedicalTest medicaltest;
	 
	 
	
	
	
	public Appointment() {}
	public String getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public Appointment(String appointmentId, Date appointmentDate, String timeSlot) {
		super();
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.timeSlot = timeSlot;
	}
	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", appointmentDate=" + appointmentDate + ", timeSlot="
				+ timeSlot + "]";
	}
	
	
}
package com.mphasis.laboratory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.laboratory.entity.Technician;

public interface TechnicianRepository extends JpaRepository<Technician, String> {

}

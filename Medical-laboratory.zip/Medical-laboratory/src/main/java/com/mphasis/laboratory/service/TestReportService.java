package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.laboratory.entity.TestReport;
import com.mphasis.laboratory.repository.TestReportRepository;


@Component("trs")
public class TestReportService {
@Autowired
TestReportRepository testreportRepo;
public TestReport create(TestReport testreport)
{
	return testreportRepo.save(testreport);
}
public List<TestReport> read()
{
	return testreportRepo.findAll();
}
public TestReport read(String testReportId)
{
	return testreportRepo.findById(testReportId).get();
}
public TestReport update(TestReport testreport)
{
	return testreportRepo.save(testreport);
}
public void delete(String testReportId)
{
	testreportRepo.delete(read(testReportId));
}
}

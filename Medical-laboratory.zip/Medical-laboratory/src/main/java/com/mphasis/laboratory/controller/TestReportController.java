package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.MedicalTest;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.entity.Technician;
import com.mphasis.laboratory.entity.TestReport;
import com.mphasis.laboratory.repository.TestReportRepository;
import com.mphasis.laboratory.service.MedicalTestService;
import com.mphasis.laboratory.service.PatientService;
import com.mphasis.laboratory.service.TechnicianService;
import com.mphasis.laboratory.service.TestReportService;
import com.sun.el.parser.ParseException;


@RestController
@CrossOrigin(origins= {"http://localhost:4200/","*"})

@RequestMapping("/testreport")
public class TestReportController {
@Autowired
TestReportService testreportService;
@Autowired
PatientService patientService;
@Autowired
MedicalTestService medicalTestService;
@Autowired
TechnicianService technicianService;
@GetMapping("/")
public List<TestReport> retrieveAllTestReports()
{
	List<TestReport>testreports= testreportService.read();
	return testreports;
}
@GetMapping("/{testReportId}")
public TestReport findTestReportById(@PathVariable("testReportId") String testReportId)
{
	return testreportService.read(testReportId);
}
@PostMapping("/")
////public TestReport addTestReport(@RequestBody TestReport testreport)
//
//billingPrice: "1000"
//medicaltest: "bloodtest"
//patient: "abc"
//result: "pass"
//technician: "123"
//testReportId: ""
//public TestReport(Long testReportId, String billingPrice, String result, Patient patient, MedicalTest medicaltest,
//	Technician technician

public TestReport addTestReport(@RequestParam("billingPrice")String billingPrice,@RequestParam("result") String result, 
		@RequestParam("patientId") Long patientId,@RequestParam("medicalTestId") String medicalTestId,@RequestParam("technicianId")String technicianId) throws ParseException
{
	
TestReport testReport=new TestReport();
testReport.setbillingPrice(billingPrice);
Patient patient=patientService.read(patientId);
System.out.println(patient);
//testReport.setPatient(patient);
MedicalTest medicalTest=medicalTestService.read(medicalTestId);
System.out.println(medicalTest);
//testReport.setMedicaltest(medicalTest);
Technician technician=technicianService.read(technicianId);
System.out.println(technician);
//testReport.setTechnician(technician);
System.out.println(testReport);
testReport.setResult(result);
return testreportService.create(testReport);

}

@PutMapping("/")
public TestReport modifyTestReport(@RequestBody TestReport testreport)
{
	return testreportService.update(testreport);
}
@DeleteMapping("/{testReportId}")
public void deleteTestReport(@PathVariable("testReportId") String testReportId)
{
	testreportService.delete(testReportId);
}
	
}

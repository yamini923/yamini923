package com.mphasis.laboratory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.laboratory.entity.MedicalTest;

public interface MedicalTestRepository extends JpaRepository<MedicalTest, String>{

}

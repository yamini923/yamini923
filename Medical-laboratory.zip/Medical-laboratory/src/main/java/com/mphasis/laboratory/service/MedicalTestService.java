package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.laboratory.entity.MedicalTest;
import com.mphasis.laboratory.repository.MedicalTestRepository;

@Component("mts")
public class MedicalTestService {
	
	@Autowired
	private MedicalTestRepository medicalTestRepo;
	
	public MedicalTest create(MedicalTest medicalTest)
	{
		return medicalTestRepo.save(medicalTest);
	}
	
	public List<MedicalTest> read()
	{
		return medicalTestRepo.findAll();
	}
	
	public MedicalTest read(String testId)
	{
		return medicalTestRepo.findById(testId).get();
	}
	
	public MedicalTest update(MedicalTest medicalTest)
	{
		return medicalTestRepo.save(medicalTest);
	}
	
	public void delete(String testId)
	{
		medicalTestRepo.delete(read(testId));
	}

}

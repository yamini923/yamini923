package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.MedicalTest;
import com.mphasis.laboratory.service.MedicalTestService;

@RestController
@RequestMapping("/medicaltest")
public class MedicalTestController {
	
	@Autowired
	MedicalTestService mts;
	
	@GetMapping("/")
	public List<MedicalTest> getAllMedicalTest()
	{
		List<MedicalTest> medicalTest = mts.read();
		return medicalTest;
	}
	
	@GetMapping("/{testId}")
	public MedicalTest findMedicalTestById(@PathVariable("testId") String testId)
	{
		return mts.read(testId);
	}
	
	@PostMapping("/")
	public MedicalTest addMedicalTest(@RequestBody MedicalTest medicalTest)
	{
		return mts.create(medicalTest);
	}
	
	@PutMapping("/")
	public MedicalTest modifyMedicalTest(@RequestBody MedicalTest medicalTest)
	{
		return mts.update(medicalTest);
	}
	
	@DeleteMapping("/{testId}")
	public void deleteMedicalTest(@PathVariable("testId") String testId)
	{
		mts.delete(testId);
	}

}
